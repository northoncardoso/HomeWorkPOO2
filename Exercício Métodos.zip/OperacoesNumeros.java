import java.util.Scanner;

public class OperacoesNumeros{
        Scanner s1 = new Scanner(System.in);
            
        public int posineg() {
            int n1, n2;
            System.out.println("Digite um número inteiro: ");
            n1 = s1.nextInt();
            if (n1 < 0) {
                n2 = 0;
                return n2;
            } else {
                n2 = 1;
                return n2;
            }
        }
        
        
        public int somaIntervalo(int n1, int n2) {
            int soma = 0;
            if( n1 < n2){
                for(int i = n1; i <= n2; i++) {
                    soma += i;   
                }    
            } else {
                for(int i = n2; i <= n1; i++){
                    soma += i;
                }
            }
            return soma;
        }
        
        
        public int divIntervalo(int a, int b, int c) {
            int soma = 0;
            int resto = 0;
            if(b < c) {	 	  	 	      	     		     		      	   	 	
                for( int i = b; i <= c; i++){
                    resto = i % a;
                    if(resto == 0) {
                        soma += i;
                    }
                }
            } else {
               for( int i = c; i <= b; i++){
                   resto = i % a;
                    if(resto == 0) {
                        soma += i;
                    } 
            }
        }
           return soma; 
        }
        
        
        public void relogio(int seg) {
            int hora, minuto, segundos;
            minuto = seg/60;
            segundos = seg%60;
            hora = seg/3600;
            minuto = seg%3600;
            if (minuto >= 60) {
                int min1 = 0;
                hora = minuto/60;
                min1 = minuto % 60;
                minuto = min1;
            }
            System.out.println(seg + " segundos equivalem a: " + hora + " h, " + minuto + " min e " + segundos + " segundos.");
        }
}
	 	  	 	      	     		     		      	   	 	
