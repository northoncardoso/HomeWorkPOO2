import java.util.Scanner;

//Gabriel Wesz e Northon Cardoso

public class Main{
    public static void main(String[] args){
        OperacoesNumeros op = new OperacoesNumeros();
        Scanner s1 = new Scanner(System.in);
        
        int n1, n2, n3, retMetodo;
        
        retMetodo = op.posineg();
        System.out.println("O primeiro metodo retorna: " + retMetodo);
        
        System.out.println("Digite um número positivo inteiro: ");
        n1 = s1.nextInt();
        System.out.println("Digite um segundo número positivo inteiro: ");
        n2 = s1.nextInt();
        retMetodo = op.somaIntervalo(n1, n2);
        System.out.println("O segundo método retorna: " + retMetodo);
        
        System.out.println("Digite um número maior ou igual a 1");
        n1 = s1.nextInt();
        System.out.println("Digite um outro número inteiro");
        n2 = s1.nextInt();
        System.out.println("Digite mais um número inteiro");
        n3 = s1.nextInt();
        retMetodo = op.divIntervalo(n1, n2, n3);
        System.out.println("O terceiro método retorna: " + retMetodo);
        
        System.out.println("Digite um valor em segundos: ");
        n1 = s1.nextInt();
        System.out.println("Resultado quarto Método(não é retorno): ");
        op.relogio(n1);
    }
}
	 	  	 	      	     		     		      	   	 	
